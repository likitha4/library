
package librarymanagementsystem;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;
import java.sql.*;



import java.lang.Object;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
//  import  utils.DateUtils;
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;*/

public class IssueBook extends JFrame implements ActionListener{
  private JPanel contentPane;
    JDateChooser dateChooser;
    private JTextField t1,t8,t9,t15,t16,t13,t10,t18;
    private JButton b1,b2,b3,b4;
    

    public static void main(String[] args) {
	new IssueBook().setVisible(true);
			
    }

    public IssueBook() {
        setBounds(400, 300, 800, 600);
	contentPane = new JPanel();
	contentPane.setBorder(new EmptyBorder(5,15, 5, 5));
	setContentPane(contentPane);
        contentPane.setBackground(Color.WHITE);
	contentPane.setLayout(null);
        
        
        

	JLabel l1 = new JLabel("Book_id");
	l1.setFont(new Font("Tahoma", Font.BOLD, 14));
	l1.setForeground(new Color(47, 79, 79));
	l1.setBounds(47, 63, 100, 23);
	contentPane.add(l1);


	t1 = new JTextField();
	t1.setForeground(new Color(47, 79, 79));
	t1.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t1.setBounds(126, 66, 86, 20);
	contentPane.add(t1);
	
	

	JLabel l8 = new JLabel("Student_id");
	l8.setForeground(new Color(47, 79, 79));
	l8.setFont(new Font("Tahoma", Font.BOLD, 14));
	l8.setBounds(384, 63, 100, 23);
	contentPane.add(l8);

	
	t8 = new JTextField();
	t8.setForeground(new Color(47, 79, 79));
	t8.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t8.setColumns(10);
	t8.setBounds(488, 66, 86, 20);
	contentPane.add(t8);

	JLabel l3= new JLabel("No_of_Books");
                   l3.setForeground(new Color(47,79,79));
                  l3.setFont(new Font("Tahoma", Font.BOLD, 14));
	l3.setBounds(399, 140, 170, 29);
	contentPane.add(l3);

                    
                    t13=new JTextField();
                    t13.setForeground(new Color(47, 79, 79));
	t13.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t13.setEditable(false);
	t13.setColumns(10);
	t13.setBounds(527, 140, 200, 29);
	contentPane.add(t13);
        
                b1 = new JButton("Search");
	b1.addActionListener(this);
	b1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
	b1.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b1.setBounds(594, 63, 100, 30);
        
	contentPane.add(b1);
        
	JLabel l15 = new JLabel(" Date of Issue :");
        
                 
	l15.setForeground(new Color(105, 105, 105));
	l15.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
	l15.setBounds(29, 139, 150, 26);
	contentPane.add(l15);
                 

                     t15 = new JTextField();
	t15.setForeground(new Color(47, 79, 79));
	t15.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t15.setEditable(false);
	t15.setColumns(10);
	t15.setBounds(157, 140, 200, 29);
	contentPane.add(t15);
        
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
                    Calendar cal = Calendar.getInstance();
              t15.setText(dateFormat.format(cal.getTime()));
 
                    JLabel l16 = new JLabel(" Date of Return :");
                    
                    
	l16.setForeground(new Color(105, 105, 105));
	l16.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
	l16.setBounds(29, 189, 150, 26);
	
         contentPane.add(l16);
        
                 t16 = new JTextField();
	t16.setForeground(new Color(47, 79, 79));
	t16.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t16.setEditable(false);
	t16.setColumns(10);
	t16.setBounds(157, 190, 200, 29);
	contentPane.add(t16);
        
       cal.add(Calendar.DATE, 15); 
                     t16.setText(dateFormat.format(cal.getTime()));
               
                     
                        b2 = new JButton("Search");
	b2.addActionListener(this);
	b2.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
	b2.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b2.setBounds(244, 63, 80, 30);
        
	contentPane.add(b2);
                     
                     
        JLabel l5=new JLabel("Status");
        l5.setForeground(new Color(47, 79, 79));
	l5.setFont(new Font("Tahoma", Font.BOLD, 14));
	l5.setBounds(444, 190, 100, 23);
	contentPane.add(l5);
        
                     
        t10 = new JTextField();
	t10.setForeground(new Color(47, 79, 79));
	t10.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t10.setEditable(false);
	t10.setColumns(10);
	t10.setBounds(527, 190, 200, 29);
	contentPane.add(t10);
        
        JLabel l9=new JLabel("Bookname");
          l9.setForeground(new Color(47, 79, 79));
	l9.setFont(new Font("Tahoma", Font.BOLD, 14));
	l9.setBounds(444, 245, 100, 23);
	contentPane.add(l9);
        
        t18=new JTextField();
        t18.setForeground(new Color(47, 79, 79));
	t18.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t18.setEditable(false);
	t18.setColumns(10);
	t18.setBounds(527, 245, 200, 29);
	contentPane.add(t18);
        
        

	b3 = new JButton("Issue");
	b3.addActionListener(this);
	b3.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
	b3.setBounds(47, 400, 118, 33);
	b3.setBackground(Color.BLACK);
        b3.setForeground(Color.WHITE);
        contentPane.add(b3);

	b4 = new JButton("Back");
	b4.addActionListener(this);
	b4.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
	b4.setBounds(199, 400, 118, 33);
	b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);
        contentPane.add(b4);
        
        
        
	JPanel panel = new JPanel();
	panel.setBorder(new TitledBorder(new LineBorder( Color.RED, 5, true), "Student-Details",
			TitledBorder.LEADING, TitledBorder.TOP, null, new Color(100, 149, 237)));
	panel.setForeground(new Color(0, 100, 0));
	panel.setBounds(3, 24, 769, 310);
                     panel.setBackground(Color.WHITE);
	contentPane.add(panel);
        
        
        
        
        
    }
    
    public void actionPerformed(ActionEvent ae){
        try{
            conn con = new conn();
            if(ae.getSource() == b1){
                String sql = "select no_of_books from student where student_id = ?";
		PreparedStatement st = con.c.prepareStatement(sql);
		st.setString(1, t8.getText());
		ResultSet rs = st.executeQuery();
		
                while (rs.next()) {
                  t13.setText(rs.getString("no_of_books"));
                 
		}
		st.close();
		rs.close();
		
            }
            if(ae.getSource() == b2){
                String sql1 = "select status, name from book where book_id = ?";
		PreparedStatement st1 = con.c.prepareStatement(sql1);
		st1.setString(1, t1.getText());
		ResultSet rs = st1.executeQuery();
		
                while (rs.next()) {
                   
                    t10.setText(rs.getString("status"));
                   t18.setText(rs.getString("name"));
                  
		}
		st1.close();
		rs.close();
		
            }
            if(ae.getSource() == b3){
                    try{
                   /*   String b=t1.getText();
                String sql1 = "select status from book where book_id="+b+"";
                   PreparedStatement st1=con.c.prepareStatement(sql1);
                st1.setString(1, t1.getText());
                ResultSet rs = st1.executeQuery();
                while(rs.next()){
                    
                }
             
                 JOptionPane.showMessageDialog(null, "Book is not available..!");*/
                        
                                       String sql="insert into issueBook(book_id, student_id, dateOfIssue, dateofreturn,bname) values(?, ?, ?,?,?)";
		PreparedStatement st = con.c.prepareStatement(sql);
                   		st.setString(1, t1.getText());
		st.setString(2, t8.getText());
	                   st.setString(3, t15.getText());
                                       st.setString(4, t16.getText());
                                       st.setString(5,t18.getText());
                                       int i= st.executeUpdate();
		if (i > 0){ //if it is true
                JOptionPane.showMessageDialog(null, "Successfully Book Issued..!");
                
                String sql2="update book set status=? where book_id=?";
                    PreparedStatement st2 = con.c.prepareStatement(sql2);
                    st2.setString(1,"Issued");
                    st2.setString(2,t1.getText());
                    int m= st2.executeUpdate();
                    if (m> 0){ //if it is true
                JOptionPane.showMessageDialog(null, "done with modification..!");
                
                   int  k=Integer.parseInt(t13.getText());
                String sql3="update student set no_of_books=? where student_id=?";
                PreparedStatement st3=con.c.prepareStatement(sql3);
                st3.setString(1, Integer.toString(k+1));
                st3.setString(2,t8.getText());
                  int m1= st3.executeUpdate();
                    if (m1> 0){ //if it is true
                JOptionPane.showMessageDialog(null, "Done..!");
                
                    }
                    }
                else{
                                                 JOptionPane.showMessageDialog(null, "error");                }
                
                     // String b=t1.getText();
                    
                    
               
                    }
                    
                    }
                    catch(Exception e){
                       e.printStackTrace();
                                }
            }
            if(ae.getSource() == b4){
                this.setVisible(false);
		new Home().setVisible(true);
			
            }
            
            con.c.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
  
}
