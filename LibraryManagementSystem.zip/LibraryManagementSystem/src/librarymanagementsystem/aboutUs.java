
package librarymanagementsystem;


import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class aboutUs  extends JFrame{
    private JPanel contentPane;

        public static void main(String[] args) {
            new aboutUs().setVisible(true);			
	}
    
        public aboutUs() {
            
            super("About Us - ");
            setIconImage(Toolkit.getDefaultToolkit().getImage("D:/library/icons/aboutus1.png"));
            setBackground(new Color(173, 216, 230));
            setBounds(500, 250, 700, 500);
		
            contentPane = new JPanel();
            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel l1 = new JLabel("New label");
            ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("librarymanagementsystem/icons/logo.png"));
            Image i2 = i1.getImage().getScaledInstance(100, 100,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            l1 = new JLabel(i3);
            l1.setBounds(500, 40, 100, 100);
            contentPane.add(l1);


            JLabel l3 = new JLabel("Library");
            l3.setForeground(Color.YELLOW);
            l3.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 34));
            l3.setBounds(160, 40, 150, 55);
            contentPane.add(l3);

            JLabel l4 = new JLabel("Mangement System");
            l4.setForeground(Color.YELLOW);
            l4.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 34));
            l4.setBounds(70, 90, 405, 40);
            contentPane.add(l4);

            
             JTextArea area=new JTextArea(" This Library Management System reduces the manual paperwork through it and gives proper information of books has been recorded automatically\n" +
" Librarian can update the information of books and manage availability and arriver record of the books.\n"+
" It saves human efforts and time.\n" +
"With the help of library management software, the customer can easily search and find the books.\n"+
   " The Library management system is nowadays essential for schools, colleges, private libraries, and other organizations.\n"+
                    "They can use this software as the purpose of books issuing and returning for renewal.\n");
                 area.setBounds(20,175, 650,600);
            area.setFont(new Font("Serif", Font.ITALIC, 18));
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            contentPane.add(area);
            area.setVisible(true);
           
                
            contentPane.setBackground(Color.DARK_GRAY);
	}
        
}
