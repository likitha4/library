
package librarymanagementsystem;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;
import java.sql.*;



import java.lang.Object;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
//  import  utils.DateUtils;
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;*/

public class IssueBook extends JFrame implements ActionListener{
  private JPanel contentPane;
    JDateChooser dateChooser;
    private JTextField t1,t8,t9,t15,t16,t13;
    private JButton b1,b2,b3,b4;
    

    public static void main(String[] args) {
	new IssueBook().setVisible(true);
			
    }

    public IssueBook() {
        setBounds(400, 300, 800, 600);
	contentPane = new JPanel();
	contentPane.setBorder(new EmptyBorder(5,15, 5, 5));
	setContentPane(contentPane);
        contentPane.setBackground(Color.WHITE);
	contentPane.setLayout(null);
        
        
        

	JLabel l1 = new JLabel("Book_id");
	l1.setFont(new Font("Tahoma", Font.BOLD, 14));
	l1.setForeground(new Color(47, 79, 79));
	l1.setBounds(47, 63, 100, 23);
	contentPane.add(l1);


	t1 = new JTextField();
	t1.setForeground(new Color(47, 79, 79));
	t1.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t1.setBounds(126, 66, 86, 20);
	contentPane.add(t1);
	
	

	JLabel l8 = new JLabel("Student_id");
	l8.setForeground(new Color(47, 79, 79));
	l8.setFont(new Font("Tahoma", Font.BOLD, 14));
	l8.setBounds(324, 63, 100, 23);
	contentPane.add(l8);

	
	t8 = new JTextField();
	t8.setForeground(new Color(47, 79, 79));
	t8.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t8.setColumns(10);
	t8.setBounds(418, 66, 86, 20);
	contentPane.add(t8);

	JLabel l3= new JLabel("No_of_Books");
                   l3.setForeground(new Color(47,79,79));
                  l3.setFont(new Font("Tahoma", Font.BOLD, 14));
	l3.setBounds(399, 140, 170, 29);
	contentPane.add(l3);

                    
                    t13=new JTextField();
                    t13.setForeground(new Color(47, 79, 79));
	t13.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t13.setEditable(false);
	t13.setColumns(10);
	t13.setBounds(527, 140, 200, 29);
	contentPane.add(t13);
        
                b1 = new JButton("Search");
	b1.addActionListener(this);
	b1.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
	b1.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b1.setBounds(534, 63, 100, 30);
        
	contentPane.add(b1);
        
	JLabel l15 = new JLabel(" Date of Issue :");
        
                 
	l15.setForeground(new Color(105, 105, 105));
	l15.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
	l15.setBounds(29, 139, 150, 26);
	contentPane.add(l15);
                 

                     t15 = new JTextField();
	t15.setForeground(new Color(47, 79, 79));
	t15.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t15.setEditable(false);
	t15.setColumns(10);
	t15.setBounds(157, 140, 200, 29);
	contentPane.add(t15);
        
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
                    Calendar cal = Calendar.getInstance();
              t15.setText(dateFormat.format(cal.getTime()));
 
                    JLabel l16 = new JLabel(" Date of Return :");
                    
                    
	l16.setForeground(new Color(105, 105, 105));
	l16.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
	l16.setBounds(29, 189, 150, 26);
	
         contentPane.add(l16);
        
                 t16 = new JTextField();
	t16.setForeground(new Color(47, 79, 79));
	t16.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	t16.setEditable(false);
	t16.setColumns(10);
	t16.setBounds(157, 190, 200, 29);
	contentPane.add(t16);
        
       cal.add(Calendar.DATE, 15); 
                     t16.setText(dateFormat.format(cal.getTime()));
               
        

	b3 = new JButton("Issue");
	b3.addActionListener(this);
	b3.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b3.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
	b3.setBounds(47, 400, 118, 33);
	b3.setBackground(Color.BLACK);
        b3.setForeground(Color.WHITE);
        contentPane.add(b3);

	b4 = new JButton("Back");
	b4.addActionListener(this);
	b4.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
	b4.setBorder(new LineBorder(new Color(192, 192, 192), 1, true));
	b4.setBounds(199, 400, 118, 33);
	b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);
        contentPane.add(b4);
        
        
        
	JPanel panel = new JPanel();
	panel.setBorder(new TitledBorder(new LineBorder( Color.RED, 5, true), "Student-Deatails",
			TitledBorder.LEADING, TitledBorder.TOP, null, new Color(100, 149, 237)));
	panel.setForeground(new Color(0, 100, 0));
	panel.setBounds(3, 24, 769, 310);
                     panel.setBackground(Color.WHITE);
	contentPane.add(panel);
        
        
        
        
        
    }
    
    public void actionPerformed(ActionEvent ae){
        try{
            conn con = new conn();
            if(ae.getSource() == b1){
                String sql = "select no_of_books from student where student_id = ?";
		PreparedStatement st = con.c.prepareStatement(sql);
		st.setString(1, t8.getText());
		ResultSet rs = st.executeQuery();
		
                while (rs.next()) {
                  t13.setText(rs.getString("no_of_books"));
                   /* t3.setText(rs.getString("isbn"));
                    t4.setText(rs.getString("publisher"));
                    t5.setText(rs.getString("edition"));
                    t6.setText(rs.getString("price"));
                    t7.setText(rs.getString("pages"));*/
		}
		st.close();
		rs.close();
		
            }
            if(ae.getSource() == b2){
                String sql = "select * from student where student_id = ?";
		PreparedStatement st = con.c.prepareStatement(sql);
		st.setString(1, t8.getText());
		ResultSet rs = st.executeQuery();
		
                while (rs.next()) {
                 /*   t9.setText(rs.getString("name"));
                    t10.setText(rs.getString("father"));
                    t11.setText(rs.getString("course"));
                    t12.setText(rs.getString("branch"));
                    t13.setText(rs.getString("year"));
                    t14.setText(rs.getString("semester"));*/
		}
		st.close();
		rs.close();
		
            }
            if(ae.getSource() == b3){
                    try{
                     
                String sql = "insert into issueBook(book_id, student_id, dateOfIssue, dateofreturn) values(?, ?, ?,?)";
		PreparedStatement st = con.c.prepareStatement(sql);
                   		st.setString(1, t1.getText());
		st.setString(2, t8.getText());
	                   st.setString(3, t15.getText());
                                       st.setString(4, t16.getText());
                                       int i= st.executeUpdate();
		if (i > 0){ //if it is true
                JOptionPane.showMessageDialog(null, "Successfully Book Issued..!");
               
                    }
                                    else
                                                 JOptionPane.showMessageDialog(null, "error");                
                    }
                    
                    catch(Exception e){
                       e.printStackTrace();
                                }
            }
            if(ae.getSource() == b4){
                this.setVisible(false);
		new Home().setVisible(true);
			
            }
            
            con.c.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
  
}
